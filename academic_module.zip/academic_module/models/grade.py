
from odoo import models, fields

class Grade(models.Model):
    _name = 'grade'
    _description = 'Grade'

    student_id = fields.Many2one('student', string='Student')
    subject_id = fields.Many2one('subject', string='Subject')
    value = fields.Float(string='Grade')
