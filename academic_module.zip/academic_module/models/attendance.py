
from odoo import models, fields

class Attendance(models.Model):
    _name = 'attendance'
    _description = 'Attendance'

    student_id = fields.Many2one('student', string='Student')
    date = fields.Date(string='Date')
    present = fields.Boolean(string='Present')
