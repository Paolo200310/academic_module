from odoo import models, fields

class AcademicAttendance(models.Model):
    _name = 'academic.attendance'
    _description = 'Attendance'

    student_id = fields.Many2one('academic.student', string='Student', required=True)
    subject_id = fields.Many2one('academic.subject', string='Subject', required=True)
    date = fields.Date(string='Date')
    present = fields.Boolean(string='Present')