
from odoo import models, fields

class Student(models.Model):
    _name = 'student'
    _description = 'Student'

    name = fields.Char(string='Name', required=True)
    semester = fields.Integer(string='Semester')
    subject_ids = fields.Many2many('subject', string='Subjects')
