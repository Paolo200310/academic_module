
from odoo import models, fields

class Task(models.Model):
    _name = 'task'
    _description = 'Task'

    subject_id = fields.Many2one('subject', string='Subject')
    title = fields.Char(string='Title')
    description = fields.Text(string='Description')
    due_date = fields.Date(string='Due Date')
