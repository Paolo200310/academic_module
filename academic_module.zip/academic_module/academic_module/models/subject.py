from odoo import models, fields

class AcademicSubject(models.Model):
    _name = 'academic.subject'
    _description = 'Subject'

    name = fields.Char(string='Name', required=True)
    description = fields.Text(string='Description')