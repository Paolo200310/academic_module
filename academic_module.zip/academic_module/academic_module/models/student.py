from odoo import models, fields

class AcademicStudent(models.Model):
    _name = 'academic.student'
    _description = 'Student'

    name = fields.Char(string='Name', required=True)
    semester = fields.Char(string='Semester')
    grade_ids = fields.One2many('academic.grade', 'student_id', string='Grades')
    attendance_ids = fields.One2many('academic.attendance', 'student_id', string='Attendances')