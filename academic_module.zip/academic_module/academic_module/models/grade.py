from odoo import models, fields

class AcademicGrade(models.Model):
    _name = 'academic.grade'
    _description = 'Grade'

    student_id = fields.Many2one('academic.student', string='Student', required=True)
    subject_id = fields.Many2one('academic.subject', string='Subject', required=True)
    score = fields.Float(string='Score')