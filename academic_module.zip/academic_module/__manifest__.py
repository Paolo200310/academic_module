{
    'name': 'Academic Module',
    'version': '16.0.1.0',
    'category': 'Education',
    'summary': 'Academic management system for students and courses',
    'author': 'ChatGPT',
    'license': 'LGPL-3',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/academic_views.xml'
    ],
    'installable': True,
    'application': True,
}