{
    'name': 'Academic Module',
    'version': '1.0',
    'summary': 'Academic management system for students and courses',
    'author': 'ChatGPT',
    'category': 'Education',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/student_views.xml',
        'views/subject_views.xml',
        'views/grade_views.xml',
        'views/attendance_views.xml',
        'views/task_views.xml',
    ],
    'installable': True,
    'application': True,
}
